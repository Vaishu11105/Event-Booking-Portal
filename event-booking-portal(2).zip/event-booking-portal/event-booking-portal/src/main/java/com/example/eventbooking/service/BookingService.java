package com.example.eventbooking.service;

import com.example.eventbooking.model.Booking;
import com.example.eventbooking.model.Event;
import com.example.eventbooking.model.BookingRequest;
import com.example.eventbooking.repository.BookingRepository;
import com.example.eventbooking.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private BookingRepository bookingRepository;

    public void createBooking(BookingRequest request) {
        Event event = eventRepository.findById(request.getEventId())
                .orElseThrow(() -> new RuntimeException("Event not found with id: " + request.getEventId()));

        if (event.getAvailableSlots() <= 0) {
            throw new RuntimeException("No slots available for this event.");
        }

        Booking booking = new Booking();
        booking.setName(request.getUserName());
        booking.setEmail(request.getUserEmail());
        booking.setEvent(event); // important

        bookingRepository.save(booking);

        event.setAvailableSlots(event.getAvailableSlots() - 1);
        eventRepository.save(event);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }
}
