package com.example.eventbooking.model;

public class BookingRequest {
    private Long eventId;
    private String userName;
    private String userEmail;

    // ✅ Getters
    public Long getEventId() {
        return eventId;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    // ✅ Setters
    public void setEventId(Long eventId) {
        this.eventId = eventId;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
