// script.js (used in both pages)

// For index.html

if (document.getElementById('eventsContainer')) {
    let events = [];

    async function fetchEvents() {
        try {
            const res = await fetch('/api/events');
            events = await res.json();
            displayEvents(events);
        } catch {
            document.getElementById('eventsContainer').innerHTML = '<p>Error loading events.</p>';
        }
    }

    function displayEvents(eventList) {
        const container = document.getElementById('eventsContainer');
        container.innerHTML = '';

        if (eventList.length === 0) {
            container.innerHTML = '<p>No events found.</p>';
            return;
        }

        eventList.forEach(event => {
            const card = document.createElement('div');
            card.className = 'event-card';
            card.innerHTML = `
        <h2>${event.name}</h2>
        <p><b>Category:</b> ${event.category}</p>
        <p><b>Date:</b> ${event.date}</p>
        <p><b>Time:</b> ${event.time}</p>
        <p><b>Location:</b> ${event.location}</p>
        <p><b>Price:</b> ₹${event.pricePerPerson.toFixed(2)}</p>
        <p><b>Slots Left:</b> ${event.availableSlots}</p>
        <button ${event.availableSlots === 0 ? 'disabled' : ''} data-id="${event.id}">Book Now</button>
      `;
            container.appendChild(card);
        });

        // Attach click handlers to Book Now buttons
        document.querySelectorAll('#eventsContainer button').forEach(button => {
            button.addEventListener('click', e => {
                const id = e.target.getAttribute('data-id');
                const selectedEvent = events.find(ev => ev.id == id);
                if (selectedEvent) {
                    localStorage.setItem('selectedEvent', JSON.stringify(selectedEvent));
                    window.location.href = 'booking.html';
                }
            });
        });
    }

    // Category buttons filter
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const category = btn.getAttribute('data-category');
            if (category === 'All') {
                displayEvents(events);
            } else {
                displayEvents(events.filter(ev => ev.category === category));
            }
        });
    });

    fetchEvents();
}


// For booking.html

if (document.getElementById('bookingForm')) {
    const selectedEvent = JSON.parse(localStorage.getItem('selectedEvent'));
    if (!selectedEvent) {
        alert('No event selected!');
        window.location.href = 'index.html';
    } else {
        document.getElementById('eventName').textContent = `Book Slot: ${selectedEvent.name}`;
    }

    const form = document.getElementById('bookingForm');
    const confirmationDiv = document.getElementById('confirmation');
    const goHomeBtn = document.getElementById('goHomeBtn');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const userName = document.getElementById('userName').value.trim();
        const userEmail = document.getElementById('userEmail').value.trim();

        if (!userName || !userEmail) {
            alert('Please fill all fields');
            return;
        }

        try {
            const res = await fetch('/api/bookings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    eventId: selectedEvent.id,
                    userName,
                    userEmail
                })
            });

            if (res.ok) {
                form.style.display = 'none';
                confirmationDiv.style.display = 'block';
            } else {
                const error = await res.json();
                alert('Booking failed: ' + (error.message || 'Unknown error'));
            }
        } catch {
            alert('Booking failed due to network error');
        }
    });

    goHomeBtn.addEventListener('click', () => {
        localStorage.removeItem('selectedEvent'); // Clear selection
        window.location.href = 'index.html';
    });
}
