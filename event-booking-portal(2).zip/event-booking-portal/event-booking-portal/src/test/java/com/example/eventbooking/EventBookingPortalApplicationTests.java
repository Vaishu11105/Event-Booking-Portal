package com.example.eventbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventBookingPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
